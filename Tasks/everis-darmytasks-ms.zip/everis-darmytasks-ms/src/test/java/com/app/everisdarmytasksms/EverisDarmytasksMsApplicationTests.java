package com.app.everisdarmytasksms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EverisDarmytasksMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
